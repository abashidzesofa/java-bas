//1 Напишите метод, который принимает три строки и строку-разделитель.
// Метод возвращает единую строку,
// состоящую из исходных строк, разделённых строкой-разделителем.
// Например, на входе "один", "два", "три", "|". На выходе: "один|два|три"
//2 Напишите метод, который выводит в консоль первый символ переданной в него строки.
public class Main {

    public static void main(String[] args) {
        System.out.println("Задание 1:");

        String s = concat("один", "два", "три", "|");
        System.out.println(s);
        System.out.println("Задание 2:");
        String str = show("Hello World!");
        System.out.println(str.charAt(0));
    }

    private static String concat(String s1, String s2, String s3, String delimiter) {
        return s1 + delimiter + s2 + delimiter + s3;
    }
    private static String show(String s1){
        return s1;
    }


    }

